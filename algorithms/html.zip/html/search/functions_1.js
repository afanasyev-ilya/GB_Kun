var searchData=
[
  ['cc_0',['cc',['../namespacelablas_1_1algorithm.html#a08966dc886244fb5d03bd0a4cbb9c4c3',1,'lablas::algorithm']]],
  ['cc_5fbfs_5fbased_5fsequential_1',['cc_bfs_based_sequential',['../namespacelablas_1_1algorithm.html#a447d06f4ca10f01a69865abf8a12076a',1,'lablas::algorithm']]]
];
