var indexSectionsWithContent =
{
  0: "bclpst",
  1: "l",
  2: "bcpst",
  3: "bcls"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Namespaces",
  2: "Files",
  3: "Functions"
};

